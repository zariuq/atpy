#!/bin/sh

export ENIGMA_ROOT="$PWD/Enigma"
export EXPRES_PROTOS="$PWD/protos"
export EXPRES_BENCHMARKS="$PWD/benchmarks"
export EXPRES_RESULTS="$PWD/00RESULTS"
export EXPRES_SOLVED="$PWD/00SOLVED"

export PATH="$PWD/bin:$PATH"
export PYTHONPATH="$PWD/../..:$PYTHONPATH"

python loop.py

