#!/usr/bin/python

from atpy import *

def train(bid, pid, name, results):
   print "Training Enigma predictor from %d results ..." % len(results)
   enigma.models.smartboost(name, results)
   new = [
      enigma.protos.standalone(pid, name), # S (.) E
      enigma.protos.combined(pid, name)    # S (+) E
   ]
   print "New Enigma strategies: \n * " + "\n * ".join(new)
   print
   return new

def loop(bid, pid):
   pids = [pid]
   results = expres.benchmarks.eval(bid, pids, 1)

   pids += train(bid, pid, "init", results)
   results.update(expres.benchmarks.eval(bid, pids, 1))

   for i in range(1,4):
      print 
      print "### Loop iteration #%d ###" % i
      print 
      pids += train(bid, pid, "loop%02d"%i, results)
      results.update(expres.benchmarks.eval(bid, pids, 1))
      
   expres.dump.processed(bid, pids, results)
   expres.dump.solved(bid, pids, results, ref=pid)

BID="mptp"
PID="auto01"

loop(BID, PID)

